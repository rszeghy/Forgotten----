FORGOTTEN █████

--------------------------

- Platform - 
	RPG Maker VX ACE

- Credits -
	Art, Music, Sound:
		Aleph Null's Resources - (https://forums.rpgmakerweb.com/index.php?threads/aleph-nulls-resources-update-7-3-16-weapon-icons.63331/)
		Starbird RTP Edits - (https://forums.rpgmakerweb.com/index.php?threads/starbird-rtp-edits.102687/)
		Iliketea's Marvelous Tiles - (https://forums.rpgmakerweb.com/index.php?threads/iliketeas-marvelous-tiles-updated-14-03-2017-closet-edits.60876/)
		Kadokawa
		Enterbrain 
		Renee Szeghy
	Story, Design, Programming:
		Renee Szeghy

- Controls -
	Arrow keys: Movement
	Z: Enter/Confirm
	X: Exit/Cancel/Menu
	Shift: Hold to sprint

- Summary -
	The player controls a character, known as M15211905, EMNE, or ████ as they try to leave the lab that they woke up in. 
	The player meets some other residents of the lab, and is able to choose how they wish to interact with these other characters. 
	The player can be merciful, cruel, or paranoid with their options. 

- Stats - 
	The player's choices impact several stats. These include: 
		MERCY
		PARANOIA
		CRUELTY
	Player choices impact the story.

- Passwords - 
	Door 1:	072109
	Door 2: 122025
	Medicine amount input:
		12
		20
		25

- Number/Name Significance - 
	Each number used for the doors corresponds to a letter:
		07 - G
		21 - U
		09 - I
		12 - L
		20 - T
		25 - Y
	Subject's number is M15211905, essentially MOUSE:
		15 - O
		21 - U
		19 - S
		05 - E
	EMNE:
		For the subject's name, the word "subject" (as in - theme, topic) in Danish.